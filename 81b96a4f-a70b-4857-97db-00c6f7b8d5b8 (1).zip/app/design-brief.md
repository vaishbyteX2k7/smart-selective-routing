# Smart Selective Routing: Design Brief
- Design read: A mobile-first routing policy lab for learners exploring domain-specific traffic decisions.
- Concept spine: The route instrument. Every interaction makes a domain policy visible as a path through a chosen route.
- Delivery tier: cinema, with an explanatory scroll-scrub journey and a working interactive console.
- Locked palette: ink navy #111A24, slate #1A2632, silver-white #E5E9EC, muted slate #9AA8B5, one dusty coral accent #D86F79.
- Locked type: Satoshi display and IBM Plex Mono telemetry labels. Sans only for a precise technical tool.
Animation mode: animated-website
- Journey shape: single-shot. One continuous approach reinforces following a signal into a routing decision.
- Journey: a slow approach toward a branching network node; copy explains domain policy and simulated metrics.
- World grammar: deep ink, silver route lines, dusty coral packet accent, glass-like nodes, fixed upper-left light, no text baked into imagery.
- Mobile framing: central branching node remains center-safe; controls remain HTML.
- Delivery budget: desktop clip under 32 MiB and mobile clip under 16 MiB.
- Section plan: interactive console, policy explanation journey, activity log, limitations note.
- CTA inventory: Open routing lab, route toggles, Run simulated probe, Add domain, Reset demo.
- Functional boundary: no system routing, VPN, DNS, proxy configuration, or live probes. All metrics and route assignments are simulated.
