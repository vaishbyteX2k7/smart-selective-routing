import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";
export const scrollScrubTheme: ScrollScrubTheme = { accent: "#D86F79", background: "#111A24", ink: "#E5E9EC", muted: "#9AA8B5" };
export const scrollScrubScenes: ScrollScrubScene[] = [{
 body: "A domain policy chooses a path. This animation is explanatory only. The console above does not change device routes or run live probes.",
 clip: "/assets/world/scene-01.mp4", id: "route-instrument", kicker: "The route instrument", label: "Policy flow",
 mobileClip: "/assets/world/scene-01-mobile.mp4", mobilePoster: "/assets/world/scene-01-mobile-poster.png", poster: "/assets/world/scene-01-poster.png",
 tags: ["Domain policy", "Simulated telemetry"], title: "Make each route explicit.", scroll: 1.3, objectPosition: "center center", mobileObjectPosition: "center center"
}];
